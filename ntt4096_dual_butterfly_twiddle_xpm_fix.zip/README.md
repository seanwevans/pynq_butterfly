# Dual-read twiddle BRAM correction

The generic dual-read profile RAM synthesized to eight RAMB36 blocks,
so the complete cyclic core consumed twelve:

- coefficient store: 4 RAMB36
- duplicated twiddle table: 8 RAMB36

This checkpoint replaces the profile RAM with one explicit
`xpm_memory_tdpram`. A 4096 x 32 true-dual-port memory should consume
four RAMB36 blocks while providing both synchronous read ports.

Icarus uses a behavioral branch selected by `__ICARUS__`; Vivado uses
the XPM implementation.
