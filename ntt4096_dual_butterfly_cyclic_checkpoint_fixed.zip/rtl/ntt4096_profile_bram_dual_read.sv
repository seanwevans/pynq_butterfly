`timescale 1ns/1ps

/*
 * Runtime-programmable 4096 x 32-bit profile table with two
 * simultaneous synchronous read ports.
 *
 * Port A is reused as the runtime write port while the arithmetic core
 * is idle. During a transform both ports are read-only, providing the
 * two twiddle words required by the paired butterfly datapaths.
 */
module ntt4096_profile_bram_dual_read (
    input  logic        clk,

    input  logic        write_enable,
    input  logic [11:0] write_address,
    input  logic [31:0] write_data,

    input  logic        read_enable_a,
    input  logic [11:0] read_address_a,
    output logic [31:0] read_data_a,

    input  logic        read_enable_b,
    input  logic [11:0] read_address_b,
    output logic [31:0] read_data_b
);

    (* ram_style = "block" *)
    logic [31:0] memory [0:4095];

    always_ff @(posedge clk)
    begin
        if (write_enable)
        begin
            memory[write_address] <=
                write_data;
        end
        else if (read_enable_a)
        begin
            read_data_a <=
                memory[read_address_a];
        end
    end

    always_ff @(posedge clk)
    begin
        if (read_enable_b)
        begin
            read_data_b <=
                memory[read_address_b];
        end
    end

`ifndef SYNTHESIS

    always @(posedge clk)
    begin
        if (
            write_enable
            && (
                read_enable_a
                || read_enable_b
            )
        )
        begin
            $display(
                "ERROR: profile write attempted during dual read"
            );

            $fatal(1);
        end
    end

`endif

endmodule
