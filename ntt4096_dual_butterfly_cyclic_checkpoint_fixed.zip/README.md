# Runtime-profile dual-butterfly N=4096 cyclic NTT checkpoint

This checkpoint combines:

- four conflict-free coefficient BRAM banks;
- one runtime-programmable dual-read twiddle table;
- a stallable two-butterfly schedule;
- two concurrent iterative modular-multiplication butterfly lanes;
- forward DIF and inverse DIT operation under q0 and q1.

The inverse transform is intentionally unscaled. Its expected result is
`4096 * input mod q`, matching the inverse phase used by the existing
polynomial multiplier before postprocessing applies `N^-1`.

Expected constant transform timing with the existing radix-4
`modmul_core` is 270337 clocks, versus 540673 clocks for the original
single-butterfly cyclic core.

## Controller correction

The first checkpoint measured 282625 cycles, exactly

    1 + 12288 * 23

rather than the intended

    1 + 12288 * 22 = 270337.

The excess was one explicit `STATE_BUTTERFLY_START` bubble per paired
entry. In this revision, both butterfly cores sample the already-valid
coefficient and twiddle BRAM outputs directly during
`STATE_READ_CAPTURE`, removing all 12288 bubbles without changing the
memory schedule or arithmetic.
