# Full dual-butterfly runtime-profile polynomial multiplier

This checkpoint integrates the verified two-butterfly cyclic NTT engine
into a complete N=4096 negacyclic polynomial multiplier.

The core keeps the existing four runtime profile tables and two
coefficient vectors:

- coefficient A: four RAMB36 banks
- coefficient B: four RAMB36 banks
- twist profile: four RAMB36
- forward twiddles: four RAMB36
- inverse twiddles: four RAMB36
- inverse scale: four RAMB36

Expected total: 24 RAMB36, unchanged from the earlier one-butterfly
runtime-profile multiplier.

Arithmetic parallelism:

- preprocessing: four A and four B coefficients
- forward transform: two butterflies on A and two on B
- pointwise multiplication: four coefficients
- inverse transform: two butterflies on A
- postprocessing: four coefficients

The exact target is 607234 cycles at 100 MHz, or 6072.34 microseconds.
The previous runtime-profile core required 1339394 cycles.
