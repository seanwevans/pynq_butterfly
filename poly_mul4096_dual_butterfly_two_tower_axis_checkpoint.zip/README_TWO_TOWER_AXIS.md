# Parallel two-tower dual-butterfly AXI checkpoint

This checkpoint wraps two complete 607234-cycle runtime-profile
dual-butterfly cores behind one 64-bit AXI4-Stream interface.

## Stream layout

Each 64-bit stream word is:

- bits 31:0: OpenFHE tower q0
- bits 63:32: OpenFHE tower q1

Profile frame:

- 16384 x 64-bit words
- 131072 bytes

Product input frame:

- 8193 x 64-bit words
- 65544 bytes

Product output frame:

- 4096 x 64-bit words
- 32768 bytes

Both towers consume and produce words in lockstep. The regression uses
randomized input gaps and randomized output backpressure and runs two
products after one profile load.

For Icarus, compile with `-DFAST_MODMUL` and
`modmul_core_fast_sim.sv`. The exact behavioral multiplier preserves
the arithmetic and handshake while making the full AXI integration
regression practical.

Synthesis must use the real `modmul_core.sv`.
